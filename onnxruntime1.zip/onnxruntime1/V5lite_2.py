import cv2
import time
import numpy as np
import argparse
import onnxruntime as ort
from UART_2 import SerialCommunication


# 设置要发送的类别标签
selected_class = "white_pp"  # 默认为橙色乒乓球
flag_ball = 1

class yolov5_lite():
    def __init__(self, model_pb_path, label_path, confThreshold=0.5, nmsThreshold=0.5):
        so = ort.SessionOptions()
        so.log_severity_level = 3
        self.net = ort.InferenceSession(model_pb_path, so, providers=['CPUExecutionProvider'])
        self.classes = list(map(lambda x: x.strip(), open(label_path, 'r').readlines()))

        self.confThreshold = confThreshold
        self.nmsThreshold = nmsThreshold
        self.input_shape = (self.net.get_inputs()[0].shape[2], self.net.get_inputs()[0].shape[3])

        # 初始化用于存储不同类别标签的置信度最大物体的中心坐标和类别标签的变量
        self.max_confidence_centers = {}
        self.max_confidence_classes = {}
        self.max_confidence_wide_high = {}
        # print("input shape: " , end="")
        # print(self.input_shape)

    def letterBox(self, srcimg, keep_ratio=True):
        top, left, newh, neww = 0, 0, self.input_shape[0], self.input_shape[1]
        if keep_ratio and srcimg.shape[0] != srcimg.shape[1]:
            hw_scale = srcimg.shape[0] / srcimg.shape[1]
            if hw_scale > 1:
                newh, neww = self.input_shape[0], int(self.input_shape[1] / hw_scale)
                img = cv2.resize(srcimg, (neww, newh), interpolation=cv2.INTER_AREA)
                left = int((self.input_shape[1] - neww) * 0.5)
                img = cv2.copyMakeBorder(img, 0, 0, left, self.input_shape[1] - neww - left, cv2.BORDER_CONSTANT,
                                         value=0)  # add border
            else:
                newh, neww = int(self.input_shape[0] * hw_scale), self.input_shape[1]
                img = cv2.resize(srcimg, (neww, newh), interpolation=cv2.INTER_AREA)
                top = int((self.input_shape[0] - newh) * 0.5)
                img = cv2.copyMakeBorder(img, top, self.input_shape[0] - newh - top, 0, 0, cv2.BORDER_CONSTANT, value=0)
        else:
            img = cv2.resize(srcimg, self.input_shape, interpolation=cv2.INTER_AREA)
        return img, newh, neww, top, left

    def postprocess(self, frame, outs, pad_hw):
        # 清空之前帧的结果
        self.max_confidence_centers.clear()
        self.max_confidence_classes.clear()

        newh, neww, padh, padw = pad_hw
        frameHeight = frame.shape[0]
        frameWidth = frame.shape[1]
        ratioh, ratiow = frameHeight / newh, frameWidth / neww

        class_max_confidences = {}  # 用于存储每个类别的最大置信度
        class_max_centers = {}  # 用于存储每个类别的最大置信度物体的中心坐标

        # 提取物体检测信息
        classIds = []
        confidences = []
        boxes = []
        for detection in outs:
            scores, classId = detection[4], detection[5]
            if scores > self.confThreshold:  # and detection[4] > self.objThreshold:
                x1 = int((detection[0] - padw) * ratiow)
                y1 = int((detection[1] - padh) * ratioh)
                x2 = int((detection[2] - padw) * ratiow)
                y2 = int((detection[3] - padh) * ratioh)
                center_x = (x1 + x2) // 2
                center_y = (y1 + y2) // 2
                classIds.append(classId)
                confidences.append(scores)
                boxes.append([x1, y1, x2, y2])

        # # Perform non maximum suppression to eliminate redundant overlapping boxes with
        # # lower confidences.
        indices = cv2.dnn.NMSBoxes(boxes, confidences, self.confThreshold, self.nmsThreshold)

        if len(indices) > 0:
            for ind in indices:
                classId = classIds[ind]
                scores = confidences[ind]

                x1, y1, x2, y2 = boxes[ind][0], boxes[ind][1], boxes[ind][2],boxes[ind][3]
                center_x = (x1 + x2) // 2
                center_y = (y1 + y2) // 2
                wide = x2 - x1
                high = y2 - y1

                class_label = self.classes[int(classId)]
                if class_label not in self.max_confidence_classes or scores > self.max_confidence_classes[class_label]:
                    self.max_confidence_centers[class_label] = (center_x, center_y)
                    self.max_confidence_classes[class_label] = scores
                    self.max_confidence_wide_high[class_label] = (wide, high)

                # frame = self.drawPred(frame, classIds[ind], confidences[ind], boxes[ind][0], boxes[ind][1], boxes[ind][2],boxes[ind][3])
                frame = self.drawPred(frame, classId, scores, x1, y1, x2, y2)

        return frame

    def drawPred(self, frame, classId, conf, x1, y1, x2, y2):
        # Draw a bounding box.
        color = (255, 255, 255)
        if classId == 0:
            color = (0, 255, 255)
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, thickness=2)

        label = '%.2f' % conf
        text = '%s:%s' % (self.classes[int(classId)], label)

        # 计算物体的中心位置
        center_x = (x1 + x2) // 2
        center_y = (y1 + y2) // 2

        # Display the label at the top of the bounding box
        labelSize, baseLine = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        y1 = max(y1, labelSize[1])
        cv2.putText(frame, text, (x1, y1 - 10), cv2.FONT_HERSHEY_TRIPLEX, 0.5, color, thickness=1)
        return frame

    def detect(self, srcimg):
        # 在每帧开始时初始化中心点坐标
        center_x, center_y = None, None  # Clear coordinates for the new frame

        img, newh, neww, top, left = self.letterBox(srcimg)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = img.astype(np.float32) / 255.0
        blob = np.expand_dims(np.transpose(img, (2, 0, 1)), axis=0)

        t1 = time.time()
        outs = self.net.run(None, {self.net.get_inputs()[0].name: blob})[0]
        cost_time = time.time() - t1
        # print(outs.shape)

        srcimg = self.postprocess(srcimg, outs, (newh, neww, top, left))
        infer_time = 'Inference Time: ' + str(int(cost_time * 1000)) + 'ms'
        cv2.putText(srcimg, infer_time, (5, 20), cv2.FONT_HERSHEY_TRIPLEX, 0.5, (0, 0, 0), thickness=1)
        return srcimg, self.max_confidence_centers, self.max_confidence_classes, self.max_confidence_wide_high


# 初始化串口通信
serial_comm = SerialCommunication()

# 连接串口
serial_comm.connect()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--imgpath', type=str, default='./0511191600_000000.jpg', help="image path")
    parser.add_argument('--modelpath', type=str, default='./v5lite_e_pp.onnx', help="onnx filepath")
    parser.add_argument('--classfile', type=str, default='./pingpong.names', help="classname filepath")
    parser.add_argument('--confThreshold', default=0.5, type=float, help='class confidence')
    parser.add_argument('--nmsThreshold', default=0.6, type=float, help='nms iou thresh')
    args = parser.parse_args()

    srcimg = cv2.imread(args.imgpath)
    net = yolov5_lite(args.modelpath, args.classfile, confThreshold=args.confThreshold, nmsThreshold=args.nmsThreshold)

    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    # print(args.classfile)
    while True:
        start = time.time()
        flag, srcimg = cap.read()
        if not flag:
            break
        #srcimg = cv2.resize(srcimg, (1000, 750))[135:615, 280:820, :].copy()
        # 调用detect方法来进行物体检测
        srcimg, max_confidence_centers, max_confidence_classes, max_confidence_wide_high = net.detect(srcimg.copy())

        # 在每一帧中打印检测到的物体的信息
        # for class_label, (center_x, center_y) in max_confidence_centers.items():
        #     confidence = max_confidence_classes[class_label]
        #     wide =  max_confidence_wide_high[class_label][0]
        #     high = max_confidence_wide_high[class_label][1]
        #     print(f"Class: {class_label}, Confidence: {confidence}, Center: ({center_x}, {center_y}), wide: {wide}, high: {high}")

        received_data = serial_comm.receive_data()
        print(f'received_date: {received_data}')

        # 根据接收到的数据设置标志位
        if received_data == '0':
            flag_ball = 0 #白球
        elif  received_data == '1':
            flag_ball = 1 #橙球

        if flag_ball == 0:
            selected_class = "white_pp"
        elif  flag_ball == 1:
            selected_class = "orange_pp"

        # 根据设置的标志位选择要发送的中心点坐标
        selected_centers = None
        if selected_class in max_confidence_centers:
            selected_centers = max_confidence_centers[selected_class]
        # 发送选定类别标签的物体坐标
        if selected_centers:
            X, Y = selected_centers
            X_1 = X *  250 // 640
            Y_1 = Y *  250 // 480
            # 在执行发送选定类别标签物体坐标的代码
            serial_comm.send_data(X_1, Y_1, flag_ball)
            # 打印结果
            print(f"X coordinates {X}, Y coordinates {Y}, flag {flag_ball}")
            print(f"X_1 coordinates {X_1}, Y_1 coordinates {Y_1}")
        else:
            # 发送无效坐标表示未找到目标
            serial_comm.send_data(255, 255, flag_ball)

        cv2.putText(srcimg, 'fps: %.2f' % (1 / (time.time() - start)), (10, 20), cv2.FONT_HERSHEY_TRIPLEX, 0.5, (255, 255, 255), thickness=1)
        cv2.imshow('detector', srcimg)

        if cv2.waitKey(20) & 0xFF == ord('q'):
            break

    # cv2.imwrite('save.jpg', srcimg)
cap.release()
cv2.destroyAllWindows()
