import serial

class SerialCommunication:
    def __init__(self, port='/dev/ttyTHS1', baudrate=115200):
        self.port = port
        self.baudrate = baudrate
        self.serial_connection = None
        self.frame_start = b'\x0c'  # 帧头，字节编码,十六进制
        self.frame_start_1 = b'\x0D' #帧头2
        self.frame_end = b'\x0b'  # 帧尾，字节编码，十六进制

    def connect(self):
        self.serial_connection = serial.Serial(self.port, self.baudrate)
        if self.serial_connection.is_open:
            print("Serial connection established.")
        else:
            print("Failed to establish serial connection.")

    def send_data(self, x, y, flag):
        # 检查串口是否已经连接且打开
        if self.serial_connection and self.serial_connection.is_open:
            # 将X轴和Y轴偏差信息编码为字符串
            data1 = bytes([x])
            data2 = bytes([y])
            data3 = bytes([flag])

            # 构造帧:包括帧头,帧头2,数据1,数据2,数据3,帧尾
            frame = self.frame_start + self.frame_start_1 + data1 + data2 + data3 + self.frame_end
            self.serial_connection.write(frame)
            print("send success")
            print(frame)

    def receive_data(self):
        # 检查串口是否已经连接且打开
        if self.serial_connection and self.serial_connection.is_open:
            if self.serial_connection.in_waiting > 0:
                return self.serial_connection.read_all()

def main():
    # 初始化串口通信
    serial_comm = SerialCommunication()

    # 连接串口
    serial_comm.connect()

    while True:
        try:
            发送数据
            x = 133
            y = 200
            serial_comm.send_data(x, y)

            # 接收数据
            received_data = serial_comm.receive_data()
            if received_data:
                print("Received:", received_data)
        except Exception as e:
            print("An error occurred:", e)

if __name__ == "__main__":
    main()
