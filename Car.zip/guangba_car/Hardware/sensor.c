#include "sensor.h"

char sensor1=0,sensor2=0,sensor3=0,sensor4=0,sensor5=0,sensor6=0;
uint16_t black;


void black_read()
{
	if(sensor4==sensor5==1)//����
		{
			black=1;
	
		}
	else if(sensor2==sensor3==1)
			black=2;	
	else
			black=0;
}


//��ȡ�����������ߵ͵�ƽ
float read_sensor()
{
    char x1=0,x2=0;
    float error=0;  //ƫ��
		sensor1 =! HAL_GPIO_ReadPin(sensor1_GPIO_Port,sensor1_Pin);
		sensor2 =! HAL_GPIO_ReadPin(sensor2_GPIO_Port,sensor2_Pin);
		sensor3 =! HAL_GPIO_ReadPin(sensor3_GPIO_Port,sensor3_Pin);
		sensor4 =! HAL_GPIO_ReadPin(sensor4_GPIO_Port,sensor4_Pin);
		sensor5 =! HAL_GPIO_ReadPin(sensor5_GPIO_Port,sensor5_Pin);
		sensor6 =! HAL_GPIO_ReadPin(sensor6_GPIO_Port,sensor6_Pin);


    x1=sensor1*1+sensor2*2+sensor3*3+sensor4*4+sensor5*5+sensor6*6;
    x2=sensor1+sensor2+sensor3+sensor4+sensor5+sensor6;

    if(x2 == 0)
    {
        error=0;
    }
    else
    {
        error=(x1/x2)-3;
    }

		black_read();

    return(error);
}

//�������
int jinshu_sensor()
{
	int jinshu_flag=0;
	if(HAL_GPIO_ReadPin(sensor_jinshu_GPIO_Port,sensor_jinshu_Pin)==0)
		jinshu_flag=1;
	else
		jinshu_flag=0;
	
	return jinshu_flag;
}


