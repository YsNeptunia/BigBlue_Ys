#include "motor.h"
#include "tim.h"



void car_go(int left,int right)
{
    if(left > 0)
    {
        HAL_GPIO_WritePin(motor_A1_GPIO_Port,motor_A1_Pin,GPIO_PIN_RESET);
        HAL_GPIO_WritePin(motor_A2_GPIO_Port,motor_A2_Pin,GPIO_PIN_SET);
        __HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_1,left);
    }
    else
    {
        HAL_GPIO_WritePin(motor_A1_GPIO_Port,motor_A1_Pin,GPIO_PIN_SET);
        HAL_GPIO_WritePin(motor_A2_GPIO_Port,motor_A2_Pin,GPIO_PIN_RESET);
        __HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_1,-left);
    }

    if(right > 0)
     {
        HAL_GPIO_WritePin(motor_B1_GPIO_Port,motor_B1_Pin,GPIO_PIN_RESET);
        HAL_GPIO_WritePin(motor_B2_GPIO_Port,motor_B2_Pin,GPIO_PIN_SET);
        __HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_2,right);
     }

    else
     {
        HAL_GPIO_WritePin(motor_B1_GPIO_Port,motor_B1_Pin,GPIO_PIN_SET);
        HAL_GPIO_WritePin(motor_B2_GPIO_Port,motor_B2_Pin,GPIO_PIN_RESET);
        __HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_2,-right );
     }
}

void car_stop()
{
    HAL_GPIO_WritePin(motor_A1_GPIO_Port,motor_A1_Pin,GPIO_PIN_RESET);
    HAL_GPIO_WritePin(motor_A2_GPIO_Port,motor_A2_Pin,GPIO_PIN_RESET);
    __HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_1,0);
	
    HAL_GPIO_WritePin(motor_B1_GPIO_Port,motor_B1_Pin,GPIO_PIN_RESET);
    HAL_GPIO_WritePin(motor_B2_GPIO_Port,motor_B2_Pin,GPIO_PIN_RESET);
    __HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_2,0);

}

void car_back()
{
    HAL_GPIO_WritePin(motor_A1_GPIO_Port,motor_A1_Pin,GPIO_PIN_SET);
    HAL_GPIO_WritePin(motor_A2_GPIO_Port,motor_A2_Pin,GPIO_PIN_RESET);
    __HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_1,500);
	
    HAL_GPIO_WritePin(motor_B1_GPIO_Port,motor_B1_Pin,GPIO_PIN_SET);
    HAL_GPIO_WritePin(motor_B2_GPIO_Port,motor_B2_Pin,GPIO_PIN_RESET);
    __HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_2,500);

}
