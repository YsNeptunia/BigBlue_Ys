#include "stdio.h"
#include "stdarg.h"
#include "usart.h"

uint8_t printf_temp[128];

void UART1_printf(const char *format,...)	//���ڴ�ӡ����
{
  unsigned short len;
  va_list args;
	va_start(args,format);
	len=vsnprintf((char*)printf_temp,sizeof(printf_temp)+1,(char*)format,args);
	
  HAL_UART_Transmit_IT(&huart1,printf_temp,len); 
}
