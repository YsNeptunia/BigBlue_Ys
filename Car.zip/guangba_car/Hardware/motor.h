#ifndef __MOTOR_H
#define __MOTOR_H
#include "main.h"


void car_go(int left,int right);
void car_stop(void);
void car_back(void);

#endif
