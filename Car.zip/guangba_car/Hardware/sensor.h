#ifndef __SENSOR_H
#define __SENSOR_H
#include "main.h"

float read_sensor(void);
int jinshu_sensor(void);



#endif
