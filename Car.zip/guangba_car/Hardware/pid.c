#include "pid.h"

extern int OUTPUT_1,OUTPUT_2,speed;


int PID_sd_x=0,PID_sd_y=0;
float Position_KP=70,Position_KI=0.0,Position_KD=15;
extern int Bias_x,Bias_y,speed;

int Position_PID_x(int Target,int Encoder)//X��pid
{

    static float Bias,Pwm,Integral_bias,Last_Bias;

    Bias=Target-Encoder;                                  //����ƫ��
    Integral_bias+=Bias;                                     //ƫ�����
    Pwm=Position_KP*Bias+Position_KI*Integral_bias+Position_KD*(Bias-Last_Bias);       //λ��ʽPID������
    Last_Bias=Bias;                                         //������һ��ƫ��

    return Pwm;                                           //����PWM
}

float Position_KP_y=120.0,Position_KI_y = 0.0,Position_KD_y = 20.0;

int Position_PID_y(int Target,int Encoder)//Y��pid
{

    static float Bias,Pwm,Integral_bias,Last_Bias;

    Bias=Target-Encoder;                                  //����ƫ��
    Integral_bias+=Bias;                                     //ƫ�����
    Pwm=Position_KP_y*Bias+Position_KI_y*Integral_bias+Position_KD_y*(Bias-Last_Bias);       //λ��ʽPID������
    Last_Bias=Bias;                                         //������һ��ƫ��

    return Pwm;                                           //����PWM
}



void speed_out()
{
	PID_sd_x = Position_PID_x (Bias_x,0);
	PID_sd_y = Position_PID_y (Bias_y,0);
	
	OUTPUT_1=speed-PID_sd_x+PID_sd_y;
	OUTPUT_2=speed+PID_sd_x+PID_sd_y;

	if(OUTPUT_1>=5000)          //����޷�
			OUTPUT_1=5000;
	else if(OUTPUT_1<=-5000)
		 OUTPUT_1=-5000;

	if(OUTPUT_2>=5000)
		 OUTPUT_2=5000;
	else if(OUTPUT_2<=-5000)
		 OUTPUT_2=-5000;
}

